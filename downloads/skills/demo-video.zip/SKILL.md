---
name: demo-video
owner: Senthilnathan
github: https://github.com/senthilsweb
description: Record a human-paced screen-capture demo video (.mp4) and optional animated .gif of a published or local webapp using Playwright's recordVideo — real animations, no stitched screenshots, no title cards or overlays. Covers DOM recon before scripting, scene planning from the app's functional docs/ADRs/README, frame-by-frame QA, dead-time trimming, and ffmpeg post-processing (H.264 faststart mp4 + palette-optimized gif under a size budget), delivered with per-scene timestamps for retakes. Use whenever Senthil asks for a demo video, walkthrough recording, screen capture, product tour, or animated gif of an app or site — even if he just says "record a demo of X".
user-invocable: true
sub-agents: none
---

# demo-video — scripted screen-capture demos of webapps

First proven on the OL Viewer demo (ol-viewer.nathansweb.com, 2026-07-19):
a 64-second Playwright recording of a live lineage app, delivered as a
2.8 MB mp4 and a 7.4 MB gif with an 11-scene timestamp table.

No sub-agents involved: the whole flow — recon, scripting, recording,
QA, encoding — runs inline in the main session, because each step feeds
the next (selectors found in recon drive the script; QA frames decide
the trim).

## Ground rules

- **Pure demo.** No title cards, no caption overlays, no cursor effects.
  Just the app, driven like a careful human would.
- **Real recording, never stitched screenshots.** Use Playwright
  `recordVideo` on a browser context so natural animations are captured.
- **Human pacing.** 1.5–2.5 s pause after every action; `mouse.move`
  with `steps: 25` before every click; total length 60–90 s unless the
  user asks otherwise.
- **Inspect before you script.** Never write selectors from memory of a
  similar app — load the page, read its DOM/source, and map the actual
  buttons, panels, and interactions of THIS version.
- **Verify before you deliver.** Extract frames at every scene time and
  look at them. A scene that silently did nothing is a retake, not a
  deliverable.

## Inputs to gather (ask only if missing)

1. **Target URL** — published URL preferred; localhost fallback. Both are
   fine: the recording shows no browser chrome, so content is identical.
2. **Feature list** — build the scene plan from the app's functional
   docs, ADRs, README, and the page source itself. If the repo is local,
   read the implementation of each interaction (click handlers, CSS
   classes) to get exact selectors and hidden features the docs miss.
3. **Data** — use the app's built-in sample/demo data if present,
   otherwise load the user's real data. Real data beats sample data when
   both work; it makes the demo credible (name real columns/records in
   the delivery notes).
4. **Outputs** — default: `demo.mp4` (LinkedIn) + `demo.gif` (README /
   blog) + per-scene timestamps. GIF is optional; confirm the size
   budget (default ≤8 MB).

## Toolchain (verified 2026-07-19)

| Tool | Why | Install |
|---|---|---|
| Playwright + Chromium | `recordVideo` produces real .webm capture | `npm i playwright && npx playwright install chromium` |
| @ffmpeg-installer/ffmpeg | Full ffmpeg (libx264 + gif + palette filters) shipped as package content — **no postinstall script**, so it works where npm blocks install scripts | `npm i @ffmpeg-installer/ffmpeg`; binary path via `require('@ffmpeg-installer/ffmpeg').path`, `chmod +x` it |
| Pillow (optional) | Frame-variance check to auto-detect when the app finished loading | usually present |

Traps hit once, avoid forever:
- Playwright's own bundled ffmpeg has **only libvpx** — no libx264, no
  gif encoder, no palettegen. Never use it for post-processing.
- `ffmpeg-static` downloads its binary in a postinstall script — blocked
  by npm allow-scripts policies. Use `@ffmpeg-installer/ffmpeg` instead.
- If the target repo has broken native deps (old duckdb etc.),
  `npm install --ignore-scripts` gets a Next.js/Vite dev server up anyway.

## Workflow

### 1. Recon

- `curl` the page; diff against the local copy if one exists.
- Read the app source end to end for interactions: element classes,
  click/dblclick handlers, keyboard shortcuts, panels, drawers, toggles.
- If data drives the demo (graphs, tables), inspect the actual data
  files first and pick the best concrete example to feature (e.g. the
  deepest lineage chain, the record with the richest fields).
- Confirm the highlight scene is possible with the available data
  BEFORE scripting — if not, generate/load better data first.

### 2. Scene plan

- One scene per feature, ordered from overview → deep-dive highlight →
  supporting features → clean finale. End on the app's best full-screen
  state.
- The user's requested order wins; adapt to what actually exists.
- Give the highlight scene the most time (linger ~3 s on the money shot).

### 3. Script

Start from `references/record-template.js`. Conventions that matter:

- 1280×720 context with `recordVideo: { size: { width: 1280, height: 720 } }`.
- A `scene(name)` logger records elapsed seconds per scene → written to
  `scenes.json` for the timestamp table.
- Wait for the app to be truly loaded (a selector or count check), not
  just `domcontentloaded`.
- For SVG/canvas apps, resolve click points with `page.evaluate` +
  `getBoundingClientRect()` on the exact sub-element (works on SVG),
  then drive `page.mouse` — locators alone often miss the interactive
  sub-target.
- Guard optional interactions (`if (await x.count())`, null-checked
  points) so a missing feature skips gracefully instead of crashing the
  whole take.
- Copy the raw `.webm` and `scenes.json` out before closing the browser.

### 4. QA the take

- Extract a frame at each scene timestamp:
  `ffmpeg -ss <t> -i raw.webm -frames:v 1 qa/f<t>.png` — and **read
  every image**. Check the scene did what its name says.
- Find when the app finished loading (frame variance jump or eyeball
  the early frames) — that is the trim point. A demo must open on the
  loaded app, never on a spinner or empty state.

### 5. Post-process

```bash
# mp4 — H.264, yuv420p, faststart: plays in every browser, LinkedIn-ready
ffmpeg -y -ss <trim> -i raw.webm -c:v libx264 -preset slow -crf 20 \
  -pix_fmt yuv420p -r 30 -movflags +faststart demo.mp4

# gif — two-pass palette; start at fps=11/960w, tune down to hit budget
ffmpeg -y -ss <trim> -i raw.webm \
  -vf "fps=10,scale=960:-1:flags=lanczos,palettegen=stats_mode=diff:max_colors=128" palette.png
ffmpeg -y -ss <trim> -i raw.webm -i palette.png \
  -lavfi "fps=10,scale=960:-1:flags=lanczos[x];[x][1:v]paletteuse=dither=bayer:bayer_scale=5:diff_mode=rectangle" demo.gif
```

GIF size knobs, in order: fps 12→10, max_colors 128→96, width 960→880,
bayer_scale 4→5. Verify the gif frame count with `ffmpeg -i demo.gif -f null -`
— macOS Preview shows gifs as static; only a browser proves animation.

### 6. Deliver

- `demo.mp4`, `demo.gif`, and `record.js` copied next to them (retakes
  are one command away).
- A timestamp table in the reply: `| 0:20 | Click collection_rate_pct →
  column trace |` — shifted by the trim offset.
- State the real numbers (duration, resolution, file sizes) and any
  honest caveat the user should know before publishing (e.g. "run
  history shows a single run because the data has one").
- Remind: gifs autoplay in browsers/GitHub; LinkedIn wants the mp4 as a
  native upload; GitHub READMEs need the gif, not a `<video>` tag.

## Retakes

Keep `record.js` and `scenes.json` with the deliverables. A retake is:
edit the named scene block, re-run, re-QA only the changed scenes,
re-encode. Never hand-edit the video.
