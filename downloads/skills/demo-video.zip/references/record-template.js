/**
 * Demo recording template — Playwright screen capture with scene logging.
 * Proven on the OL Viewer demo (2026-07-19). Adapt the SCENES section per app;
 * keep the helpers and conventions.
 *
 * Run: DEMO_URL=https://your-app.example.com node record.js
 * Output: demo-raw.webm + scenes.json in this directory.
 */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const URL = process.env.DEMO_URL || 'http://localhost:3000/';
const OUT = path.join(__dirname, 'video');

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 1280, height: 720 },
    recordVideo: { dir: OUT, size: { width: 1280, height: 720 } },
  });
  const page = await context.newPage();

  // ---- scene timestamp logger (drives the delivery table + retakes) ----
  const t0 = Date.now();
  const scenes = [];
  const scene = name => {
    const t = (Date.now() - t0) / 1000;
    scenes.push({ t, name });
    console.log(`[${t.toFixed(1)}s] ${name}`);
  };
  const pause = ms => page.waitForTimeout(ms);

  // ---- human-like pointing: deliberate move, settle, then click ----
  const moveClick = async (pt, settle = 400) => {
    if (!pt) return false;                      // missing target: skip, don't crash
    await page.mouse.move(pt.x, pt.y, { steps: 25 });
    await pause(settle);
    await page.mouse.click(pt.x, pt.y);
    return true;
  };

  // ---- SVG/canvas targets: resolve exact sub-element screen coords ----
  // getBoundingClientRect works on SVG elements; adapt the selector logic
  // to the app under demo (find by class + visible text, return center).
  const svgPoint = (selector, text) => page.evaluate(([selector, text]) => {
    const el = [...document.querySelectorAll(selector)]
      .find(e => !text || e.textContent.includes(text));
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
  }, [selector, text]);

  // ======================= SCENES (adapt per app) =========================
  // Order: overview -> deep-dive highlight (linger ~3s) -> supporting
  // features -> clean full-screen finale. 1.5-2.5s pause after every action.

  scene('S1 load + overview');
  await page.goto(URL, { waitUntil: 'domcontentloaded' });
  // Wait for TRUE readiness, not domcontentloaded — a selector/count that
  // only appears once the app has data. The empty pre-load frames get
  // trimmed in post using this scene's timestamp.
  await page.waitForSelector('#app-ready-selector', { timeout: 60000 });
  await pause(2500);
  scene('S1 loaded (trim point)');

  // Example: deliberate pan on a canvas/graph surface
  // await page.mouse.move(500, 400); await page.mouse.down();
  // await page.mouse.move(650, 340, { steps: 40 }); await page.mouse.up();
  // await pause(1500);

  scene('S2 highlight feature');
  // const pt = await svgPoint('g.card text.name', 'the_money_shot_item');
  // await moveClick(pt);
  // await pause(3000);                         // linger on the money shot

  // Guard optional features so a missing one skips gracefully:
  // const opt = page.locator('#maybe-present').first();
  // if (await opt.count()) { await opt.click(); await pause(2000); }

  scene('S9 clean finale');
  // await page.click('#reset-view'); await pause(3500);   // hold final frame

  // ========================================================================

  scene('end');
  const video = page.video();
  await context.close();                        // flushes the recording
  fs.copyFileSync(await video.path(), path.join(__dirname, 'demo-raw.webm'));
  fs.writeFileSync(path.join(__dirname, 'scenes.json'), JSON.stringify(scenes, null, 2));
  await browser.close();
  console.log('RAW OK demo-raw.webm — QA frames next, then trim + encode.');
})().catch(e => { console.error(e); process.exit(1); });
